Phaser_Game_Template
====================

Basic files needed to start a Phaser 2D project

When Creating a Game using Phaser 2D, the same basic setup is pretty much always done.
This project is to help you skip the repetive steps of that process and give you a few examples of some basic functions.
